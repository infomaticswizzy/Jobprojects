package repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import entity.Stock;


@Repository
public interface StockRepo extends JpaRepository <Stock, Long >  {

	 Stock getById(Long id);
		
	 Optional<Stock> findById(Long id);
	
}
