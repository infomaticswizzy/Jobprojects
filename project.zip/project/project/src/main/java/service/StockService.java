package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Stock;
import repository.StockRepo;


@Service
public class StockService {

        @Autowired	
		private StockRepo stockRepo;

        public List<Stock> getStocks() 
		{
			return stockRepo.findAll();
		}

		public Stock createStock(Stock stock)
		{
			return stockRepo.save(stock);
	    }
		
		public Optional<Stock> getStock(Long id)
		{
			 return stockRepo.findById(id);
		}
		
		public Stock getStockById(Long id) 
		{
	         return stockRepo.getById(id);
	    }   

		public void updateStock(Long id, Stock stock)
		{
		    stockRepo.save(stock);
		}

	 
	    
	  }


