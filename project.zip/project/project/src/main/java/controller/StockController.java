package controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import entity.Stock;
import service.StockService;


@RestController
public class StockController {

	@Autowired
    StockService stockService;
	
	@GetMapping("api/stocks")
	public ResponseEntity<List<Stock>> getAllStocks ()
	  {
		return new ResponseEntity<List<Stock>>(stockService.getStocks(), HttpStatus.OK);
	  }
	
    @GetMapping(value = "/api/stocks/{id}")
    public Optional<Stock> getStockById(@PathVariable Long id)
    {
    	return stockService.getStock(id);
    }
	 
	
    @PutMapping(value="/api/stocks/{id}")
    public String updateStock (@RequestBody Stock stock, @PathVariable Long id) 
     {
 	    stockService.updateStock(id, stock);
 	    return "Stock Updated Successfully";
     }
	 
    @PostMapping(value="api/createStock", consumes = {MediaType.APPLICATION_JSON_VALUE})
    public @ResponseBody ResponseEntity<List<Stock>> CreateStock(@RequestBody Stock stock, @DateTimeFormat(pattern = "yyyy-MM-dd")
    LocalDate createDate)  
    {
    	stockService.createStock(stock);
    	return new ResponseEntity<List<Stock>>(HttpStatus.OK);
    }
    
    
	
}
